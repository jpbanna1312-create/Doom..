package com.example.countdown

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.SystemClock
import android.widget.RemoteViews

class CountdownWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
        schedule(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == TICK) {
            updateAll(context)
            schedule(context)
        }
    }

    override fun onDisabled(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(tickIntent(context))
    }

    companion object {
        const val TICK = "com.example.countdown.TICK"

        private fun tickIntent(c: Context): PendingIntent =
            PendingIntent.getBroadcast(
                c, 1,
                Intent(c, CountdownWidget::class.java).setAction(TICK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        fun schedule(c: Context) {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val next = (System.currentTimeMillis() / 60000 + 1) * 60000
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, tickIntent(c))
        }

        fun updateAll(c: Context) {
            val mgr = AppWidgetManager.getInstance(c)
            val ids = mgr.getAppWidgetIds(ComponentName(c, CountdownWidget::class.java))
            ids.forEach { update(c, mgr, it) }
        }

        fun update(c: Context, mgr: AppWidgetManager, id: Int) {
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setTextViewText(R.id.title, Store.title(c).uppercase())

            val p = Store.parts(Store.target(c))
            rv.setTextViewText(R.id.mo, "%02d".format(p[0]))
            rv.setTextViewText(R.id.d, "%02d".format(p[1]))
            rv.setTextViewText(R.id.h, "%02d".format(p[2]))

            // minutes:seconds is a system-driven chronometer, so seconds tick live
            val remainMs = (p[3] * 60L + p[4]) * 1000L
            val running = p[0] + p[1] + p[2] + p[3] + p[4] > 0
            val base = SystemClock.elapsedRealtime() + remainMs - (System.currentTimeMillis() % 1000)
            rv.setChronometerCountDown(R.id.ms, true)
            rv.setChronometer(R.id.ms, if (running) base else SystemClock.elapsedRealtime(), null, running)

            val f = Store.imageFile(c)
            val bmp = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
            if (bmp != null) rv.setImageViewBitmap(R.id.bg, bmp)
            else rv.setImageViewResource(R.id.bg, R.drawable.bg_default)

            val open = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            mgr.updateAppWidget(id, rv)
        }
    }
}
