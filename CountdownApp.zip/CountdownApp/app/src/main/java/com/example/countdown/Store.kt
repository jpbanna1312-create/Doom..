package com.example.countdown

import android.content.Context
import java.io.File
import java.util.Calendar

object Store {
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun title(c: Context): String = p(c).getString("title", "Doomsday is coming") ?: "Countdown"

    fun target(c: Context): Long = p(c).getLong("target", defaultTarget())

    fun save(c: Context, title: String, target: Long) {
        p(c).edit().putString("title", title).putLong("target", target).apply()
    }

    fun imageFile(c: Context) = File(c.filesDir, "bg.jpg")

    private fun defaultTarget(): Long {
        val cal = Calendar.getInstance()
        cal.set(2026, Calendar.DECEMBER, 18, 0, 0, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    /** returns [months, days, hours, minutes, seconds] */
    fun parts(target: Long): IntArray {
        val now = Calendar.getInstance()
        now.set(Calendar.MILLISECOND, 0)
        val t = Calendar.getInstance()
        t.timeInMillis = target
        if (!now.before(t)) return intArrayOf(0, 0, 0, 0, 0)

        var mo = (t.get(Calendar.YEAR) - now.get(Calendar.YEAR)) * 12 +
                t.get(Calendar.MONTH) - now.get(Calendar.MONTH)
        var a = now.clone() as Calendar
        a.add(Calendar.MONTH, mo)
        if (a.after(t)) {
            mo--
            a = now.clone() as Calendar
            a.add(Calendar.MONTH, mo)
        }
        val sec = (t.timeInMillis - a.timeInMillis) / 1000
        val d = (sec / 86400).toInt()
        val h = ((sec % 86400) / 3600).toInt()
        val m = ((sec % 3600) / 60).toInt()
        val s = (sec % 60).toInt()
        return intArrayOf(mo, d, h, m, s)
    }
}
