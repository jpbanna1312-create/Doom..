package com.example.countdown

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.io.FileOutputStream
import java.text.DateFormat
import java.util.Calendar

class MainActivity : Activity() {

    private val cal: Calendar = Calendar.getInstance()
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private val pickImage = 101

    private lateinit var etTitle: EditText
    private lateinit var btnDate: Button
    private lateinit var btnTime: Button
    private lateinit var tvImg: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        setContentView(R.layout.activity_main)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        etTitle = findViewById(R.id.etTitle)
        btnDate = findViewById(R.id.btnDate)
        btnTime = findViewById(R.id.btnTime)
        tvImg = findViewById(R.id.tvImg)

        etTitle.setText(Store.title(this))
        cal.timeInMillis = Store.target(this)
        refreshLabels()

        btnDate.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                cal.set(y, m, d)
                refreshLabels()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        btnTime.setOnClickListener {
            TimePickerDialog(this, { _, h, min ->
                cal.set(Calendar.HOUR_OF_DAY, h)
                cal.set(Calendar.MINUTE, min)
                refreshLabels()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
        }

        findViewById<Button>(R.id.btnImage).setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(i, "Choose picture"), pickImage)
        }

        findViewById<Button>(R.id.btnClearImg).setOnClickListener {
            Store.imageFile(this).delete()
            refreshLabels()
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val title = etTitle.text.toString().trim().ifEmpty { "Countdown" }
            Store.save(this, title, cal.timeInMillis)
            CountdownWidget.updateAll(this)
            CountdownWidget.schedule(this)
            if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
            }
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun refreshLabels() {
        btnDate.text = "Date: " + DateFormat.getDateInstance(DateFormat.LONG).format(cal.time)
        btnTime.text = "Time: " + DateFormat.getTimeInstance(DateFormat.SHORT).format(cal.time)
        tvImg.text = if (Store.imageFile(this).exists()) "Picture selected" else "No picture (default green background)"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == RESULT_OK) {
            data?.data?.let { saveImage(it) }
            refreshLabels()
        }
    }

    private fun saveImage(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 960 && bounds.outHeight / (sample * 2) >= 960) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val src = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return

            // widgets can only carry small bitmaps, so crop to 480x288
            val w = 480
            val h = 288
            val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
            val sw = (src.width * scale).toInt().coerceAtLeast(w)
            val sh = (src.height * scale).toInt().coerceAtLeast(h)
            val scaled = Bitmap.createScaledBitmap(src, sw, sh, true)
            val out = Bitmap.createBitmap(scaled, (sw - w) / 2, (sh - h) / 2, w, h)
            FileOutputStream(Store.imageFile(this)).use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not load picture", Toast.LENGTH_SHORT).show()
        }
    }
}
